lista = [1,2,3]

defmodule AplicaFnc do
  def aplica(fnc, lista) do
    Enum.filter(lista, fnc)
  end
end


IO.inspect AplicaFnc.aplica(fn (elemento) -> elemento >= 2 end, lista)