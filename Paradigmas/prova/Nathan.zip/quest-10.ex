notas_da_turma = [
  {"Alice", [9.5, 8.0, 7.5]},
  {"João", [8.0, 7.0, 6.5]},
  {"Pedro", [9, 9.5, 9.0]},
   {"Lucas", []},
]


defmodule CalcMedia do
  def media(matriz) do
    notas = Enum.filter(matriz, fn {_nomes, notas} -> length(notas) > 0 end)
    notas_unificadas = Enum.flat_map(notas, fn {_nomes, notas} -> notas end)
    notas_cnt = length(notas_unificadas)
    
    if notas_cnt > 0 do
      media_final = Enum.reduce(notas_unificadas, fn (x, acc) -> x + acc end) / notas_cnt
      {:ok, media_final}
    else
      {:error, "Não há notas"}
    end
  end
end

IO.inspect(CalcMedia.media(notas_da_turma))