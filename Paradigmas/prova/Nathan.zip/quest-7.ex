lista = [1,2,3]

defmodule AplicaFnc do
  def aplica(fnc, lista) do
    Enum.map(lista, fnc)
  end
end

IO.inspect AplicaFnc.aplica(fn (n) -> n * 2 end, lista)

