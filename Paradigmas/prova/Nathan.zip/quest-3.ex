
par = fn (num) -> rem(num, 2) == 0 end

IO.inspect par.(23)