defmodule Fatorial do
  def fat(0), do: 1
  def fat(n), do: n * fat(n-1)
end

IO.inspect Fatorial.fat(3)


