
defmodule Ex04 do
  def dobro(lista) do
    lista_dobro = Enum.map(lista, fn (elemento) -> elemento * 2 end)
    IO.inspect lista_dobro
  end
end

Ex04.dobro([1, 2, 3, 4])